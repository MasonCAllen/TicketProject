﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project7
{
    public partial class frmLogin : Form
    {
        internal Dictionary<string, CustomerAcct> UserDataMap;

        public frmLogin()
        {
            InitializeComponent();
        }

        private void LblCreateAccount_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmAcctCreation accountform = new frmAcctCreation();
            accountform.UserDataMap = UserDataMap;
            accountform.ShowDialog();
            this.Show();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string email = txtEmailLogin.Text.Trim();
            string password = txtPasswordLogin.Text.Trim();
           
            if (UserDataMap.ContainsKey(email) == false)
            {
                MessageBox.Show("Invalid e-mail or password");
                return;
            }

            CustomerAcct customer = UserDataMap[email];
            if (customer.Password != password)
            {
                MessageBox.Show("Invalid e-mail or password");
                return;
            }

            // TODO make rest of forms 
            MessageBox.Show("Login Successful!");

            this.Hide();
            FrmBuyTickets buyTickets = new FrmBuyTickets();
            buyTickets.Customer = customer;
            buyTickets.ShowDialog();
            


        }
    }
}
