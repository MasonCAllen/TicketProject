﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Project7
{
    public partial class FrmBuyTickets : Form
    {
        private CustomerAcct customer;
        List<CustomerData> OrdersList;

        public FrmBuyTickets()
        {
            InitializeComponent();
            Initalize();
        }


        internal CustomerAcct Customer { get => customer; set => customer = value; }

        private void BtnBuy_Click(object sender, EventArgs e)
        {
            int llCount;
            int clCount;
            int udCount;

            try
            {
                 llCount = int.Parse(comboLower.Text);
                 clCount = int.Parse(comboClub.Text);
                 udCount = int.Parse(comboUpper.Text);
            }
            catch(Exception error)
            {
                MessageBox.Show("Please enter a valid amount", "Invalid Input");
                return;
               
            }

            if (verifyTickets(llCount, clCount, udCount))
            {
                CustomerData order  = new CustomerData();
                order.Email = customer.Email;
                order.Name = customer.Name;
                order.Age = customer.Age;
                order.TicketsLower = llCount;
                order.TicketsUpper = udCount;
                order.TicketsClub =  clCount;
                OrdersList.Add(order);

                FrmPurchase frmPurchase = new FrmPurchase();
                frmPurchase.Order = order;
                frmPurchase.Initialize();
                this.Hide();
                frmPurchase.ShowDialog();

               
                DialogResult result = 
                    MessageBox.Show("Can't wait to see you! " + order.Name + "\n" +
                                    "Summary: \n" +
                                    "Amount to be Charged: " + order.TotalCost.ToString("c") + "\n" +
                                    "Contact E-Mail: " + order.Email + "\n\n" + 
                                    "Please click YES to confirm your order" , 
                                    "Confirmation", 
                                    MessageBoxButtons.YesNoCancel);
                if(result == DialogResult.Yes)
                {
                    //get Random Number 
                    Random r = new Random();
                    int randNum = r.Next(1000, 9999);
                    order.ConfirmationNumber = randNum;
                    CustomerDataFile.Write(OrdersList);

                    MessageBox.Show("Congrats! \n" +
                                    " Your confirmation number: " + randNum.ToString());
                }
        



                //  TODO Save The Order

            }
                
           
        }

        /**
         * this method will verify that there are enough tickets remaining to sell for the amount requested
         */
        private Boolean verifyTickets(int llCount,int clCount,int udCount)

        {
            int llTotalCount =0;
            int clTotalCount =0;
            int udTotalCount =0;
            foreach (var order in OrdersList)
            {
                
                llTotalCount = llTotalCount + order.TicketsLower;
                clTotalCount = clTotalCount + order.TicketsClub;
                udTotalCount = udTotalCount + order.TicketsUpper;

            }
            if ((llTotalCount + llCount) > 200)
            {
                MessageBox.Show("There is not enough remaining tickets. Please reduce the number of tickets.", "Error");
                comboLower.Focus();
                return false;
            }
            if ((clTotalCount + clCount) > 75)
            {
                MessageBox.Show("There is not enough remaining tickets. Please reduce the number of tickets.", "Error");
                comboClub.Focus();
                return false;
            }
            if ((udTotalCount + udCount) > 200)
            {
                MessageBox.Show("There is not enough remaining tickets. Please reduce the number of tickets.", "Error");
                comboUpper.Focus();
                return false;
            }
            return true; 
        }

        private void IsSoldOut()
        {
           
            int llTotal = 0;
            int udTotal = 0;
            int clTotal = 0;

            foreach (var order in OrdersList)
            {
                llTotal += order.TicketsLower;
                udTotal += order.TicketsUpper;
                clTotal += order.TicketsClub;

            }
            if (llTotal >= 200)
            {
                lblLowerLevel.Text = "Sold Out";
                lblLowerLevel.ForeColor = Color.Red;
                comboLower.Hide();
            }
            if (clTotal >= 75)
            {
                lblClubLevel.Text = "Sold Out";
                lblClubLevel.ForeColor = Color.Red;
                comboClub.Hide();
            }
            if (udTotal >= 200)
            {
                lblUpperDeck.Text = "Sold Out";
                lblUpperDeck.ForeColor = Color.Red;
                comboUpper.Hide();
            }
        }

        void Initalize()
        {

            try
            {
                OrdersList = CustomerDataFile.Read();
            }
            catch (Exception error)
            {
                OrdersList = new List<CustomerData>();
            }

            IsSoldOut();

        }
    }
}
