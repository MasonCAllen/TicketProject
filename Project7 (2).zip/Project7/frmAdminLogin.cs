﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project7
{
    public partial class frmAdminLogin : Form
    {
        public frmAdminLogin()
        {
            InitializeComponent();
        }

        private void BtnAdminLogin_Click(object sender, EventArgs e)
        {
            if (txtAdminUsername.Text == "admin" && txtAdminPassword.Text == "BACS287")
            {
                frmAdminChart frmAdminChart = new frmAdminChart();
                this.Hide();
                frmAdminChart.ShowDialog();
            }
            else
            {
                MessageBox.Show("Invaild Username or Pasword");
            }
        }
    }
}
