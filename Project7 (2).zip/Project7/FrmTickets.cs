﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ReadWriteCsv;

namespace Project7
{
    public partial class frmGetTickets : Form
    {
        Dictionary<string, CustomerAcct> UserDataMap;
        public frmGetTickets()
        {
            InitializeComponent();
            Initalize();

        }

        private void BtnGetTickets_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmLogin emailform = new frmLogin();
            emailform.UserDataMap = UserDataMap;
            emailform.ShowDialog();
            this.Close();
        }
        void Initalize()
        {
            
            try
            {
                UserDataMap = CustomerAcctFile.Read();
            }
            catch (Exception error)
            {
                UserDataMap = new Dictionary<string, CustomerAcct>();
            }

        }

        private void Lbladmin_Click(object sender, EventArgs e)
        {
            frmAdminLogin frmAdminLogin = new frmAdminLogin();
            this.Hide();
            frmAdminLogin.ShowDialog();
            this.Close();
        }
    }
}
