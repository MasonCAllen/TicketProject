﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project7
{
    public partial class frmAdminChart : Form
    {
        List<CustomerData> orders;

        public frmAdminChart()
        {
            InitializeComponent();
            Initialize();
        }

        private void Initialize()
        {
            var source = new BindingSource();
            orders = CustomerDataFile.Read();
            source.DataSource = orders;
            dataGridView1.DataSource = source;

            int TotalSales = 0;
            int TotalLower = 200;
            int TotalUpper = 200;
            int TotalClub = 75;

            foreach (var order in orders)
            {
                TotalSales += order.TotalCost;
                TotalLower -= order.TicketsLower;
                TotalUpper -= order.TicketsUpper;
                TotalClub -= order.TicketsClub;
            }
            lblTotalSales.Text = "Total Sales " + TotalSales.ToString("c");
            lblLowerLevelAmt.Text = TotalLower.ToString();
            lblUpperAmt.Text = TotalUpper.ToString();
            lblClubAmt.Text = TotalClub.ToString();
            
        }


        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void BtnFind_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();

            int confirmnum;

            try
            {
                confirmnum = int.Parse(txtConfirmationNumber.Text);
            }
            catch
            {
                MessageBox.Show("Please enter a number");
                return;
            }

            int idx = 0;
            string message = null;

            foreach (var order in orders)
            {
                if (order.ConfirmationNumber == confirmnum)
                {
                    dataGridView1.Rows[idx].Selected = true;
                    message = "Found Confirmation Number: " + order.ConfirmationNumber +
                              "\nName: " + order.Name +
                              "\nTotal Charge: " + order.TotalCost.ToString("c");
                    break;
                }
                idx++;
            }
            if (message != null)
            {
                MessageBox.Show(message);
            }
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
