﻿namespace Project7
{
    partial class FrmBuyTickets
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpBuyTickets = new System.Windows.Forms.GroupBox();
            this.comboUpper = new System.Windows.Forms.ComboBox();
            this.comboClub = new System.Windows.Forms.ComboBox();
            this.comboLower = new System.Windows.Forms.ComboBox();
            this.btnBuy = new System.Windows.Forms.Button();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.lblUpperDeck = new System.Windows.Forms.Label();
            this.lblClubLevel = new System.Windows.Forms.Label();
            this.lblLowerLevel = new System.Windows.Forms.Label();
            this.grpBuyTickets.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpBuyTickets
            // 
            this.grpBuyTickets.Controls.Add(this.comboUpper);
            this.grpBuyTickets.Controls.Add(this.comboClub);
            this.grpBuyTickets.Controls.Add(this.comboLower);
            this.grpBuyTickets.Controls.Add(this.btnBuy);
            this.grpBuyTickets.Controls.Add(this.lblQuantity);
            this.grpBuyTickets.Controls.Add(this.lblUpperDeck);
            this.grpBuyTickets.Controls.Add(this.lblClubLevel);
            this.grpBuyTickets.Controls.Add(this.lblLowerLevel);
            this.grpBuyTickets.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBuyTickets.Location = new System.Drawing.Point(12, 12);
            this.grpBuyTickets.Name = "grpBuyTickets";
            this.grpBuyTickets.Size = new System.Drawing.Size(445, 385);
            this.grpBuyTickets.TabIndex = 0;
            this.grpBuyTickets.TabStop = false;
            this.grpBuyTickets.Text = "Tickets";
            // 
            // comboUpper
            // 
            this.comboUpper.FormattingEnabled = true;
            this.comboUpper.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "Other..."});
            this.comboUpper.Location = new System.Drawing.Point(243, 221);
            this.comboUpper.Name = "comboUpper";
            this.comboUpper.Size = new System.Drawing.Size(167, 24);
            this.comboUpper.TabIndex = 10;
            this.comboUpper.Text = "0";
            // 
            // comboClub
            // 
            this.comboClub.FormattingEnabled = true;
            this.comboClub.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "Other..."});
            this.comboClub.Location = new System.Drawing.Point(243, 147);
            this.comboClub.Name = "comboClub";
            this.comboClub.Size = new System.Drawing.Size(167, 24);
            this.comboClub.TabIndex = 9;
            this.comboClub.Text = "0";
            // 
            // comboLower
            // 
            this.comboLower.FormattingEnabled = true;
            this.comboLower.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "Other..."});
            this.comboLower.Location = new System.Drawing.Point(243, 81);
            this.comboLower.Name = "comboLower";
            this.comboLower.Size = new System.Drawing.Size(167, 24);
            this.comboLower.TabIndex = 8;
            this.comboLower.Text = "0";
            // 
            // btnBuy
            // 
            this.btnBuy.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnBuy.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnBuy.Location = new System.Drawing.Point(128, 295);
            this.btnBuy.Name = "btnBuy";
            this.btnBuy.Size = new System.Drawing.Size(153, 46);
            this.btnBuy.TabIndex = 7;
            this.btnBuy.Text = "Buy";
            this.btnBuy.UseVisualStyleBackColor = false;
            this.btnBuy.Click += new System.EventHandler(this.BtnBuy_Click);
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Location = new System.Drawing.Point(296, 38);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(68, 16);
            this.lblQuantity.TabIndex = 3;
            this.lblQuantity.Text = "Quantity:";
            // 
            // lblUpperDeck
            // 
            this.lblUpperDeck.AutoSize = true;
            this.lblUpperDeck.Location = new System.Drawing.Point(6, 224);
            this.lblUpperDeck.Name = "lblUpperDeck";
            this.lblUpperDeck.Size = new System.Drawing.Size(143, 16);
            this.lblUpperDeck.TabIndex = 2;
            this.lblUpperDeck.Text = "Upper Deck: $50.00";
            // 
            // lblClubLevel
            // 
            this.lblClubLevel.AutoSize = true;
            this.lblClubLevel.Location = new System.Drawing.Point(7, 155);
            this.lblClubLevel.Name = "lblClubLevel";
            this.lblClubLevel.Size = new System.Drawing.Size(133, 16);
            this.lblClubLevel.TabIndex = 1;
            this.lblClubLevel.Text = "Club Level: $75.00";
            // 
            // lblLowerLevel
            // 
            this.lblLowerLevel.AutoSize = true;
            this.lblLowerLevel.Location = new System.Drawing.Point(6, 89);
            this.lblLowerLevel.Name = "lblLowerLevel";
            this.lblLowerLevel.Size = new System.Drawing.Size(151, 16);
            this.lblLowerLevel.TabIndex = 0;
            this.lblLowerLevel.Text = "Lower Level: $125.00";
            // 
            // FrmBuyTickets
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 409);
            this.Controls.Add(this.grpBuyTickets);
            this.Name = "FrmBuyTickets";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tickets";
            this.grpBuyTickets.ResumeLayout(false);
            this.grpBuyTickets.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpBuyTickets;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblUpperDeck;
        private System.Windows.Forms.Label lblClubLevel;
        private System.Windows.Forms.Label lblLowerLevel;
        private System.Windows.Forms.Button btnBuy;
        private System.Windows.Forms.ComboBox comboUpper;
        private System.Windows.Forms.ComboBox comboClub;
        private System.Windows.Forms.ComboBox comboLower;
    }
}