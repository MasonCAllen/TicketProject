﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project7
{
    class CustomerAcct
    {
        private string name;
        private int age;
        private string email;
        private string password;

        public string Password { get => password; set => password = value; }
        public string Email { get => email; set => email = value; }
        public int Age { get => age; set => age = value; }
        public string Name { get => name; set => name = value; }
    }

}
