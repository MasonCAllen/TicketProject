﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project7
{
    class CustomerData
    {
        private string name;
        private int age;
        private string email;
        private string creditCard;
        private string nameOnCreditCard;
        private string csvNumber;
        private int ticketsLower = 0;
        private int ticketsClub = 0;
        private int ticketsUpper = 0;
        private int confirmationNumber = 0;
        

        

        
        public string Email { get => email; set => email = value; }
        public int Age { get => age; set => age = value; }
        public string Name { get => name; set => name = value; }
        public string CreditCard { get => creditCard; set => creditCard = value; }
        public string NameOnCreditCard { get => nameOnCreditCard; set => nameOnCreditCard = value; }
        public string CsvNumber { get => csvNumber; set => csvNumber = value; }
        public int TicketsLower { get => ticketsLower; set => ticketsLower = value; }
        public int TicketsClub { get => ticketsClub; set => ticketsClub = value; }
        public int TicketsUpper { get => ticketsUpper; set => ticketsUpper = value; }
        public int ConfirmationNumber { get => confirmationNumber; set => confirmationNumber = value; }
       

        public int TotalCost { get => (ticketsLower * 125) + (ticketsClub * 75) + (ticketsUpper * 50);}
    }
}
