﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ReadWriteCsv;

namespace Project7
{
    class CustomerAcctFile
    {
        public static Dictionary<string, CustomerAcct> Read()
        {
            Dictionary<string, CustomerAcct> data = new Dictionary<string, CustomerAcct>();
            using (CsvFileReader reader = new CsvFileReader("CustomerAccount.csv"))
            {

                CsvRow row = new CsvRow();
                while (reader.ReadRow(row))
                {
                    CustomerAcct customer = new CustomerAcct();
                    customer.Name = row[0];
                    customer.Age = int.Parse(row[1]);
                    customer.Email = row[2];
                    customer.Password = row[3];

                    data.Add(customer.Email, customer);

                }
            }
            return data;
        }

        public static void Write(Dictionary<string, CustomerAcct> data)
        {
            using (CsvFileWriter writer = new CsvFileWriter("CustomerAccount.csv"))
            {
                foreach (var pair in data)
                {
                    CustomerAcct customerData = pair.Value;
                    CsvRow row = new CsvRow();
                    row.Add(customerData.Name);
                    row.Add(customerData.Age.ToString());
                    row.Add(customerData.Email);
                    row.Add(customerData.Password);

                    writer.WriteRow(row);
                }
            }
        }
    }
}
