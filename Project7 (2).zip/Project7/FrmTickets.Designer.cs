﻿namespace Project7
{
    partial class frmGetTickets
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbladmin = new System.Windows.Forms.Label();
            this.lbl335 = new System.Windows.Forms.Label();
            this.btnGetTickets = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbladmin
            // 
            this.lbladmin.AutoSize = true;
            this.lbladmin.Location = new System.Drawing.Point(2, 9);
            this.lbladmin.Name = "lbladmin";
            this.lbladmin.Size = new System.Drawing.Size(35, 13);
            this.lbladmin.TabIndex = 0;
            this.lbladmin.Text = "admin";
            this.lbladmin.Click += new System.EventHandler(this.Lbladmin_Click);
            // 
            // lbl335
            // 
            this.lbl335.AutoSize = true;
            this.lbl335.Font = new System.Drawing.Font("Georgia", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl335.Location = new System.Drawing.Point(112, 110);
            this.lbl335.Name = "lbl335";
            this.lbl335.Size = new System.Drawing.Size(212, 56);
            this.lbl335.TabIndex = 1;
            this.lbl335.Text = "3:35pm";
            // 
            // btnGetTickets
            // 
            this.btnGetTickets.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnGetTickets.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetTickets.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnGetTickets.Location = new System.Drawing.Point(144, 222);
            this.btnGetTickets.Name = "btnGetTickets";
            this.btnGetTickets.Size = new System.Drawing.Size(135, 62);
            this.btnGetTickets.TabIndex = 2;
            this.btnGetTickets.Text = "Get Tickets!";
            this.btnGetTickets.UseVisualStyleBackColor = false;
            this.btnGetTickets.Click += new System.EventHandler(this.BtnGetTickets_Click);
            // 
            // frmGetTickets
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(437, 341);
            this.Controls.Add(this.btnGetTickets);
            this.Controls.Add(this.lbl335);
            this.Controls.Add(this.lbladmin);
            this.Name = "frmGetTickets";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GetTickets";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbladmin;
        private System.Windows.Forms.Label lbl335;
        private System.Windows.Forms.Button btnGetTickets;
    }
}

