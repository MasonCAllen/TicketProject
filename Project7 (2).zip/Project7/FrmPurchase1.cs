﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project7
{
    public partial class FrmPurchase : Form
    {
        private CustomerData order;
        

        public FrmPurchase()
        {
            InitializeComponent();
        }

        internal CustomerData Order { get => order; set => order = value; }
      
        public void Initialize()
        {
            
            lblTotalCost.Text = order.TotalCost.ToString("c");
        }

        private void LblCVV_Click(object sender, EventArgs e)
        {

        }

        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            string ccNum = txtCreditCardNum.Text;
            string ccCSV = txtCSV.Text;
            string ccName = txtCSV.Text;

            // Verify that user has entered all data
            if (ccNum == null || ccCSV == null || ccName == null)
            {
                MessageBox.Show("Please enter data for all fields");
                return;
            }

            // Verify that information is numeric
            try
            {
               
                int CSV = int.Parse(txtCSV.Text);
                long ccnum = long.Parse(txtCreditCardNum.Text);
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Please enter a number");
                return;
            }
            
            if(ccNum.Length != 16)
            {
                MessageBox.Show("Invalid Credit Card Number");
                txtCreditCardNum.Focus();
                return;
            }
            if (ccCSV.Length != 3)
            {
                MessageBox.Show("Invalid CSV Number");
                txtCSV.Focus();
                return;
            }

            order.NameOnCreditCard = txtNameOnCard.Text;
            order.CsvNumber = txtCSV.Text;
            order.CreditCard = txtCreditCardNum.Text;
            this.Hide();


        }

        private void FrmPurchase_Load(object sender, EventArgs e)
        {

        }

    }
}
