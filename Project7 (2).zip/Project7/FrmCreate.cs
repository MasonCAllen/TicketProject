﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project7
{
    public partial class frmAcctCreation : Form
    {
        internal Dictionary<string, CustomerAcct> UserDataMap;

        public frmAcctCreation()
        {
            InitializeComponent();
        }

        private void BtnCreate_Click(object sender, EventArgs e)
        {

            string email = txtEmailAcct.Text.Trim();

            if (UserDataMap.ContainsKey(email))
            {
                MessageBox.Show("E-mail address " + txtEmailAcct.Text + " already exists. Please use a different e-mail address" , "E-mail already exists");
            }
            else
            {

                if (RegexUtilities.IsValidEmail(email) == false)
                {   
                    MessageBox.Show("E-mail address " + txtEmailAcct.Text + " is invalid. Please use a different e-mail address", "E-mail Error");
                    return;
                }
                // else if (txtAgeAcct.Text)
                int age;
                try
                {
                    age = int.Parse(txtAgeAcct.Text);
                }
                catch(Exception error)
                {
                    MessageBox.Show("Invalid age, please enter a number." , "Invalid Input");
                    return;
                }
                if(age < 17)
                {
                    MessageBox.Show("Invalid age, you must be older than 16 to create an account.", "Invalid Age");
                    return;
                }

                CustomerAcct customerAcct = new CustomerAcct();
                customerAcct.Name = txtNameAcct.Text;
                customerAcct.Age = int.Parse(txtAgeAcct.Text);
                customerAcct.Email = txtEmailAcct.Text;
                customerAcct.Password = txtPasswordAcct.Text;

                UserDataMap.Add(customerAcct.Email, customerAcct);
                CustomerAcctFile.Write(UserDataMap);

                this.Hide();
                
                // TODO SHOW ORDER FORM
            }
            
        }
    }
}
