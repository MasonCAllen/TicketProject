﻿namespace Project7
{
    partial class frmAcctCreation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.lblAge = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNameAcct = new System.Windows.Forms.TextBox();
            this.txtAgeAcct = new System.Windows.Forms.TextBox();
            this.txtEmailAcct = new System.Windows.Forms.TextBox();
            this.txtPasswordAcct = new System.Windows.Forms.TextBox();
            this.btnCreate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(23, 20);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(53, 16);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name:";
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAge.Location = new System.Drawing.Point(23, 76);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(40, 16);
            this.lblAge.TabIndex = 1;
            this.lblAge.Text = "Age:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(23, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "E-mail:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(-1, 191);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Password:";
            // 
            // txtNameAcct
            // 
            this.txtNameAcct.Location = new System.Drawing.Point(94, 16);
            this.txtNameAcct.Name = "txtNameAcct";
            this.txtNameAcct.Size = new System.Drawing.Size(170, 20);
            this.txtNameAcct.TabIndex = 4;
            // 
            // txtAgeAcct
            // 
            this.txtAgeAcct.Location = new System.Drawing.Point(94, 76);
            this.txtAgeAcct.Name = "txtAgeAcct";
            this.txtAgeAcct.Size = new System.Drawing.Size(170, 20);
            this.txtAgeAcct.TabIndex = 5;
            // 
            // txtEmailAcct
            // 
            this.txtEmailAcct.Location = new System.Drawing.Point(94, 131);
            this.txtEmailAcct.Name = "txtEmailAcct";
            this.txtEmailAcct.Size = new System.Drawing.Size(170, 20);
            this.txtEmailAcct.TabIndex = 6;
            // 
            // txtPasswordAcct
            // 
            this.txtPasswordAcct.Location = new System.Drawing.Point(94, 187);
            this.txtPasswordAcct.Name = "txtPasswordAcct";
            this.txtPasswordAcct.PasswordChar = '*';
            this.txtPasswordAcct.Size = new System.Drawing.Size(170, 20);
            this.txtPasswordAcct.TabIndex = 7;
            // 
            // btnCreate
            // 
            this.btnCreate.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnCreate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreate.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCreate.Location = new System.Drawing.Point(122, 224);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(93, 40);
            this.btnCreate.TabIndex = 8;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = false;
            this.btnCreate.Click += new System.EventHandler(this.BtnCreate_Click);
            // 
            // frmAcctCreation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(356, 276);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.txtPasswordAcct);
            this.Controls.Add(this.txtEmailAcct);
            this.Controls.Add(this.txtAgeAcct);
            this.Controls.Add(this.txtNameAcct);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblAge);
            this.Controls.Add(this.lblName);
            this.Name = "frmAcctCreation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Account Creation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNameAcct;
        private System.Windows.Forms.TextBox txtAgeAcct;
        private System.Windows.Forms.TextBox txtEmailAcct;
        private System.Windows.Forms.TextBox txtPasswordAcct;
        private System.Windows.Forms.Button btnCreate;
    }
}