﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ReadWriteCsv;

namespace Project7
{
    class CustomerDataFile
    {
        public static List<CustomerData> Read()
        {
            List<CustomerData> data = new List<CustomerData>();
          
            using (CsvFileReader reader = new CsvFileReader("CustomerData.csv"))
            {

                CsvRow row = new CsvRow();
                while (reader.ReadRow(row))
                {
                    CustomerData customer = new CustomerData();
                    customer.Name = row[0];
                    customer.Age = int.Parse(row[1]);
                    customer.Email = row[2];
                    customer.CreditCard = row[3];
                    customer.NameOnCreditCard = row[4];
                    customer.CsvNumber = row[5];
                    customer.TicketsLower = int.Parse(row[6]);
                    customer.TicketsClub = int.Parse(row[7]);
                    customer.TicketsUpper = int.Parse(row[8]);
                    customer.ConfirmationNumber = int.Parse(row[9]);
                    

                    data.Add(customer);
                }
            }
            return data;
        }

        public static void Write(List <CustomerData> data)
        {
            using (CsvFileWriter writer = new CsvFileWriter("CustomerData.csv"))
            {

                foreach (var customerData in data)
                {
                    
                    CsvRow row = new CsvRow();
                    row.Add(customerData.Name);
                    row.Add(customerData.Age.ToString());
                    row.Add(customerData.Email);
                    row.Add(customerData.CreditCard);
                    row.Add(customerData.NameOnCreditCard);
                    row.Add(customerData.CsvNumber);
                    row.Add(customerData.TicketsLower.ToString());
                    row.Add(customerData.TicketsClub.ToString());
                    row.Add(customerData.TicketsUpper.ToString());
                    row.Add(customerData.ConfirmationNumber.ToString());
                    

                    writer.WriteRow(row);

                
                }
            }
        }
    }
}
