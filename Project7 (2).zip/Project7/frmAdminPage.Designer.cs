﻿namespace Project7
{
    partial class frmAdminChart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.grpSeatsRemaining = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCL = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblUpperAmt = new System.Windows.Forms.Label();
            this.lblClubAmt = new System.Windows.Forms.Label();
            this.lblLowerLevelAmt = new System.Windows.Forms.Label();
            this.grpLookup = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtConfirmationNumber = new System.Windows.Forms.TextBox();
            this.btnFind = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblTotalSales = new System.Windows.Forms.Label();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.confirmationNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ticketsLowerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ticketsClubDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ticketsUpperDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.orderDataSourceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.grpSeatsRemaining.SuspendLayout();
            this.grpLookup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerDataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderDataSourceBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.Column1,
            this.TotalCost,
            this.confirmationNumberDataGridViewTextBoxColumn,
            this.ticketsLowerDataGridViewTextBoxColumn,
            this.ticketsClubDataGridViewTextBoxColumn,
            this.ticketsUpperDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.customerDataBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(8, 183);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(932, 351);
            this.dataGridView1.TabIndex = 0;
            // 
            // grpSeatsRemaining
            // 
            this.grpSeatsRemaining.Controls.Add(this.lblUpperAmt);
            this.grpSeatsRemaining.Controls.Add(this.lblClubAmt);
            this.grpSeatsRemaining.Controls.Add(this.lblLowerLevelAmt);
            this.grpSeatsRemaining.Controls.Add(this.label3);
            this.grpSeatsRemaining.Controls.Add(this.lblCL);
            this.grpSeatsRemaining.Controls.Add(this.label1);
            this.grpSeatsRemaining.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSeatsRemaining.Location = new System.Drawing.Point(12, 59);
            this.grpSeatsRemaining.Name = "grpSeatsRemaining";
            this.grpSeatsRemaining.Size = new System.Drawing.Size(468, 105);
            this.grpSeatsRemaining.TabIndex = 1;
            this.grpSeatsRemaining.TabStop = false;
            this.grpSeatsRemaining.Text = "Seats Remaining";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Lower Level:";
            // 
            // lblCL
            // 
            this.lblCL.AutoSize = true;
            this.lblCL.Location = new System.Drawing.Point(180, 29);
            this.lblCL.Name = "lblCL";
            this.lblCL.Size = new System.Drawing.Size(85, 16);
            this.lblCL.TabIndex = 1;
            this.lblCL.Text = "Club Level:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(347, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Upper Deck:";
            this.label3.Click += new System.EventHandler(this.Label3_Click);
            // 
            // lblUpperAmt
            // 
            this.lblUpperAmt.AccessibleName = "lblLowerLevelAmt";
            this.lblUpperAmt.AutoSize = true;
            this.lblUpperAmt.Location = new System.Drawing.Point(347, 77);
            this.lblUpperAmt.Name = "lblUpperAmt";
            this.lblUpperAmt.Size = new System.Drawing.Size(19, 16);
            this.lblUpperAmt.TabIndex = 5;
            this.lblUpperAmt.Text = "U";
            // 
            // lblClubAmt
            // 
            this.lblClubAmt.AccessibleName = "lblClubAmt";
            this.lblClubAmt.AutoSize = true;
            this.lblClubAmt.Location = new System.Drawing.Point(180, 77);
            this.lblClubAmt.Name = "lblClubAmt";
            this.lblClubAmt.Size = new System.Drawing.Size(18, 16);
            this.lblClubAmt.TabIndex = 4;
            this.lblClubAmt.Text = "C";
            // 
            // lblLowerLevelAmt
            // 
            this.lblLowerLevelAmt.AccessibleName = "lblLowerLevelAmt";
            this.lblLowerLevelAmt.AutoSize = true;
            this.lblLowerLevelAmt.Location = new System.Drawing.Point(22, 77);
            this.lblLowerLevelAmt.Name = "lblLowerLevelAmt";
            this.lblLowerLevelAmt.Size = new System.Drawing.Size(16, 16);
            this.lblLowerLevelAmt.TabIndex = 3;
            this.lblLowerLevelAmt.Text = "L";
            // 
            // grpLookup
            // 
            this.grpLookup.Controls.Add(this.btnFind);
            this.grpLookup.Controls.Add(this.txtConfirmationNumber);
            this.grpLookup.Controls.Add(this.label2);
            this.grpLookup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpLookup.Location = new System.Drawing.Point(509, 34);
            this.grpLookup.Name = "grpLookup";
            this.grpLookup.Size = new System.Drawing.Size(435, 129);
            this.grpLookup.TabIndex = 2;
            this.grpLookup.TabStop = false;
            this.grpLookup.Text = "Guest Lookup";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Confirmation Number:";
            // 
            // txtConfirmationNumber
            // 
            this.txtConfirmationNumber.Location = new System.Drawing.Point(168, 51);
            this.txtConfirmationNumber.Name = "txtConfirmationNumber";
            this.txtConfirmationNumber.Size = new System.Drawing.Size(125, 22);
            this.txtConfirmationNumber.TabIndex = 1;
            // 
            // btnFind
            // 
            this.btnFind.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnFind.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnFind.Location = new System.Drawing.Point(129, 85);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(90, 38);
            this.btnFind.TabIndex = 2;
            this.btnFind.Text = "Find";
            this.btnFind.UseVisualStyleBackColor = false;
            this.btnFind.Click += new System.EventHandler(this.BtnFind_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnClose.Location = new System.Drawing.Point(756, 567);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(141, 40);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // lblTotalSales
            // 
            this.lblTotalSales.AutoSize = true;
            this.lblTotalSales.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalSales.ForeColor = System.Drawing.Color.Red;
            this.lblTotalSales.Location = new System.Drawing.Point(72, 19);
            this.lblTotalSales.Name = "lblTotalSales";
            this.lblTotalSales.Size = new System.Drawing.Size(104, 20);
            this.lblTotalSales.TabIndex = 5;
            this.lblTotalSales.Text = "Total Sales:";
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.DataPropertyName = "Email";
            this.Column1.HeaderText = "Email";
            this.Column1.Name = "Column1";
            // 
            // TotalCost
            // 
            this.TotalCost.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.TotalCost.DataPropertyName = "TotalCost";
            this.TotalCost.HeaderText = "Total Cost";
            this.TotalCost.Name = "TotalCost";
            this.TotalCost.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // confirmationNumberDataGridViewTextBoxColumn
            // 
            this.confirmationNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.confirmationNumberDataGridViewTextBoxColumn.DataPropertyName = "ConfirmationNumber";
            this.confirmationNumberDataGridViewTextBoxColumn.HeaderText = "ConfirmationNumber";
            this.confirmationNumberDataGridViewTextBoxColumn.Name = "confirmationNumberDataGridViewTextBoxColumn";
            // 
            // ticketsLowerDataGridViewTextBoxColumn
            // 
            this.ticketsLowerDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ticketsLowerDataGridViewTextBoxColumn.DataPropertyName = "TicketsLower";
            this.ticketsLowerDataGridViewTextBoxColumn.HeaderText = "Lower Level Seats";
            this.ticketsLowerDataGridViewTextBoxColumn.Name = "ticketsLowerDataGridViewTextBoxColumn";
            // 
            // ticketsClubDataGridViewTextBoxColumn
            // 
            this.ticketsClubDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ticketsClubDataGridViewTextBoxColumn.DataPropertyName = "TicketsClub";
            this.ticketsClubDataGridViewTextBoxColumn.HeaderText = "Club Level Seats";
            this.ticketsClubDataGridViewTextBoxColumn.Name = "ticketsClubDataGridViewTextBoxColumn";
            // 
            // ticketsUpperDataGridViewTextBoxColumn
            // 
            this.ticketsUpperDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ticketsUpperDataGridViewTextBoxColumn.DataPropertyName = "TicketsUpper";
            this.ticketsUpperDataGridViewTextBoxColumn.HeaderText = "Upper Deck Seats";
            this.ticketsUpperDataGridViewTextBoxColumn.Name = "ticketsUpperDataGridViewTextBoxColumn";
            // 
            // customerDataBindingSource
            // 
            this.customerDataBindingSource.DataSource = typeof(Project7.CustomerData);
            // 
            // orderDataSourceBindingSource
            // 
            this.orderDataSourceBindingSource.DataSource = typeof(Project7.OrderDataSource);
            // 
            // frmAdminChart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(952, 611);
            this.Controls.Add(this.lblTotalSales);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.grpLookup);
            this.Controls.Add(this.grpSeatsRemaining);
            this.Controls.Add(this.dataGridView1);
            this.Name = "frmAdminChart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.grpSeatsRemaining.ResumeLayout(false);
            this.grpSeatsRemaining.PerformLayout();
            this.grpLookup.ResumeLayout(false);
            this.grpLookup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerDataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderDataSourceBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox grpSeatsRemaining;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblUpperAmt;
        private System.Windows.Forms.Label lblClubAmt;
        private System.Windows.Forms.Label lblLowerLevelAmt;
        private System.Windows.Forms.GroupBox grpLookup;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.TextBox txtConfirmationNumber;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblTotalSales;
        private System.Windows.Forms.BindingSource orderDataSourceBindingSource;
        private System.Windows.Forms.BindingSource customerDataBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn confirmationNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ticketsLowerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ticketsClubDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ticketsUpperDataGridViewTextBoxColumn;
    }
}